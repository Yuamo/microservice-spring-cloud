package com.yumao.cloud.microservicesimplecousumermovie;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicroserviceSimpleCousumerMovieApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicroserviceSimpleCousumerMovieApplication.class, args);
	}
}
